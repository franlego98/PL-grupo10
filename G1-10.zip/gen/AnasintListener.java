// Generated from C:/Users/Javier/IdeaProjects/PL-grupo10/src\Anasint.g4 by ANTLR 4.9
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link Anasint}.
 */
public interface AnasintListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link Anasint#programa}.
	 * @param ctx the parse tree
	 */
	void enterPrograma(Anasint.ProgramaContext ctx);
	/**
	 * Exit a parse tree produced by {@link Anasint#programa}.
	 * @param ctx the parse tree
	 */
	void exitPrograma(Anasint.ProgramaContext ctx);
	/**
	 * Enter a parse tree produced by {@link Anasint#variables}.
	 * @param ctx the parse tree
	 */
	void enterVariables(Anasint.VariablesContext ctx);
	/**
	 * Exit a parse tree produced by {@link Anasint#variables}.
	 * @param ctx the parse tree
	 */
	void exitVariables(Anasint.VariablesContext ctx);
	/**
	 * Enter a parse tree produced by {@link Anasint#decl_var}.
	 * @param ctx the parse tree
	 */
	void enterDecl_var(Anasint.Decl_varContext ctx);
	/**
	 * Exit a parse tree produced by {@link Anasint#decl_var}.
	 * @param ctx the parse tree
	 */
	void exitDecl_var(Anasint.Decl_varContext ctx);
	/**
	 * Enter a parse tree produced by {@link Anasint#identificador_declaracion}.
	 * @param ctx the parse tree
	 */
	void enterIdentificador_declaracion(Anasint.Identificador_declaracionContext ctx);
	/**
	 * Exit a parse tree produced by {@link Anasint#identificador_declaracion}.
	 * @param ctx the parse tree
	 */
	void exitIdentificador_declaracion(Anasint.Identificador_declaracionContext ctx);
	/**
	 * Enter a parse tree produced by {@link Anasint#tipo_de_dato}.
	 * @param ctx the parse tree
	 */
	void enterTipo_de_dato(Anasint.Tipo_de_datoContext ctx);
	/**
	 * Exit a parse tree produced by {@link Anasint#tipo_de_dato}.
	 * @param ctx the parse tree
	 */
	void exitTipo_de_dato(Anasint.Tipo_de_datoContext ctx);
	/**
	 * Enter a parse tree produced by {@link Anasint#subprogramas}.
	 * @param ctx the parse tree
	 */
	void enterSubprogramas(Anasint.SubprogramasContext ctx);
	/**
	 * Exit a parse tree produced by {@link Anasint#subprogramas}.
	 * @param ctx the parse tree
	 */
	void exitSubprogramas(Anasint.SubprogramasContext ctx);
	/**
	 * Enter a parse tree produced by {@link Anasint#funcion}.
	 * @param ctx the parse tree
	 */
	void enterFuncion(Anasint.FuncionContext ctx);
	/**
	 * Exit a parse tree produced by {@link Anasint#funcion}.
	 * @param ctx the parse tree
	 */
	void exitFuncion(Anasint.FuncionContext ctx);
	/**
	 * Enter a parse tree produced by {@link Anasint#identificador_funcion}.
	 * @param ctx the parse tree
	 */
	void enterIdentificador_funcion(Anasint.Identificador_funcionContext ctx);
	/**
	 * Exit a parse tree produced by {@link Anasint#identificador_funcion}.
	 * @param ctx the parse tree
	 */
	void exitIdentificador_funcion(Anasint.Identificador_funcionContext ctx);
	/**
	 * Enter a parse tree produced by {@link Anasint#procedimiento}.
	 * @param ctx the parse tree
	 */
	void enterProcedimiento(Anasint.ProcedimientoContext ctx);
	/**
	 * Exit a parse tree produced by {@link Anasint#procedimiento}.
	 * @param ctx the parse tree
	 */
	void exitProcedimiento(Anasint.ProcedimientoContext ctx);
	/**
	 * Enter a parse tree produced by {@link Anasint#identificador_procedimiento}.
	 * @param ctx the parse tree
	 */
	void enterIdentificador_procedimiento(Anasint.Identificador_procedimientoContext ctx);
	/**
	 * Exit a parse tree produced by {@link Anasint#identificador_procedimiento}.
	 * @param ctx the parse tree
	 */
	void exitIdentificador_procedimiento(Anasint.Identificador_procedimientoContext ctx);
	/**
	 * Enter a parse tree produced by {@link Anasint#argumento_subprograma_dev}.
	 * @param ctx the parse tree
	 */
	void enterArgumento_subprograma_dev(Anasint.Argumento_subprograma_devContext ctx);
	/**
	 * Exit a parse tree produced by {@link Anasint#argumento_subprograma_dev}.
	 * @param ctx the parse tree
	 */
	void exitArgumento_subprograma_dev(Anasint.Argumento_subprograma_devContext ctx);
	/**
	 * Enter a parse tree produced by {@link Anasint#argumento_subprograma}.
	 * @param ctx the parse tree
	 */
	void enterArgumento_subprograma(Anasint.Argumento_subprogramaContext ctx);
	/**
	 * Exit a parse tree produced by {@link Anasint#argumento_subprograma}.
	 * @param ctx the parse tree
	 */
	void exitArgumento_subprograma(Anasint.Argumento_subprogramaContext ctx);
	/**
	 * Enter a parse tree produced by {@link Anasint#instrucciones}.
	 * @param ctx the parse tree
	 */
	void enterInstrucciones(Anasint.InstruccionesContext ctx);
	/**
	 * Exit a parse tree produced by {@link Anasint#instrucciones}.
	 * @param ctx the parse tree
	 */
	void exitInstrucciones(Anasint.InstruccionesContext ctx);
	/**
	 * Enter a parse tree produced by {@link Anasint#tipo_instruccion}.
	 * @param ctx the parse tree
	 */
	void enterTipo_instruccion(Anasint.Tipo_instruccionContext ctx);
	/**
	 * Exit a parse tree produced by {@link Anasint#tipo_instruccion}.
	 * @param ctx the parse tree
	 */
	void exitTipo_instruccion(Anasint.Tipo_instruccionContext ctx);
	/**
	 * Enter a parse tree produced by {@link Anasint#tipo_instruccion2}.
	 * @param ctx the parse tree
	 */
	void enterTipo_instruccion2(Anasint.Tipo_instruccion2Context ctx);
	/**
	 * Exit a parse tree produced by {@link Anasint#tipo_instruccion2}.
	 * @param ctx the parse tree
	 */
	void exitTipo_instruccion2(Anasint.Tipo_instruccion2Context ctx);
	/**
	 * Enter a parse tree produced by {@link Anasint#ins_asignacion}.
	 * @param ctx the parse tree
	 */
	void enterIns_asignacion(Anasint.Ins_asignacionContext ctx);
	/**
	 * Exit a parse tree produced by {@link Anasint#ins_asignacion}.
	 * @param ctx the parse tree
	 */
	void exitIns_asignacion(Anasint.Ins_asignacionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code identLista}
	 * labeled alternative in {@link Anasint#identificador_variables}.
	 * @param ctx the parse tree
	 */
	void enterIdentLista(Anasint.IdentListaContext ctx);
	/**
	 * Exit a parse tree produced by the {@code identLista}
	 * labeled alternative in {@link Anasint#identificador_variables}.
	 * @param ctx the parse tree
	 */
	void exitIdentLista(Anasint.IdentListaContext ctx);
	/**
	 * Enter a parse tree produced by the {@code identVarSimple}
	 * labeled alternative in {@link Anasint#identificador_variables}.
	 * @param ctx the parse tree
	 */
	void enterIdentVarSimple(Anasint.IdentVarSimpleContext ctx);
	/**
	 * Exit a parse tree produced by the {@code identVarSimple}
	 * labeled alternative in {@link Anasint#identificador_variables}.
	 * @param ctx the parse tree
	 */
	void exitIdentVarSimple(Anasint.IdentVarSimpleContext ctx);
	/**
	 * Enter a parse tree produced by {@link Anasint#expresion_asignacion}.
	 * @param ctx the parse tree
	 */
	void enterExpresion_asignacion(Anasint.Expresion_asignacionContext ctx);
	/**
	 * Exit a parse tree produced by {@link Anasint#expresion_asignacion}.
	 * @param ctx the parse tree
	 */
	void exitExpresion_asignacion(Anasint.Expresion_asignacionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code AsigTrue}
	 * labeled alternative in {@link Anasint#expresion_asignacion1}.
	 * @param ctx the parse tree
	 */
	void enterAsigTrue(Anasint.AsigTrueContext ctx);
	/**
	 * Exit a parse tree produced by the {@code AsigTrue}
	 * labeled alternative in {@link Anasint#expresion_asignacion1}.
	 * @param ctx the parse tree
	 */
	void exitAsigTrue(Anasint.AsigTrueContext ctx);
	/**
	 * Enter a parse tree produced by the {@code AsigFalse}
	 * labeled alternative in {@link Anasint#expresion_asignacion1}.
	 * @param ctx the parse tree
	 */
	void enterAsigFalse(Anasint.AsigFalseContext ctx);
	/**
	 * Exit a parse tree produced by the {@code AsigFalse}
	 * labeled alternative in {@link Anasint#expresion_asignacion1}.
	 * @param ctx the parse tree
	 */
	void exitAsigFalse(Anasint.AsigFalseContext ctx);
	/**
	 * Enter a parse tree produced by the {@code AsigExplicit}
	 * labeled alternative in {@link Anasint#expresion_asignacion1}.
	 * @param ctx the parse tree
	 */
	void enterAsigExplicit(Anasint.AsigExplicitContext ctx);
	/**
	 * Exit a parse tree produced by the {@code AsigExplicit}
	 * labeled alternative in {@link Anasint#expresion_asignacion1}.
	 * @param ctx the parse tree
	 */
	void exitAsigExplicit(Anasint.AsigExplicitContext ctx);
	/**
	 * Enter a parse tree produced by the {@code AsigLista}
	 * labeled alternative in {@link Anasint#expresion_asignacion1}.
	 * @param ctx the parse tree
	 */
	void enterAsigLista(Anasint.AsigListaContext ctx);
	/**
	 * Exit a parse tree produced by the {@code AsigLista}
	 * labeled alternative in {@link Anasint#expresion_asignacion1}.
	 * @param ctx the parse tree
	 */
	void exitAsigLista(Anasint.AsigListaContext ctx);
	/**
	 * Enter a parse tree produced by the {@code AsignFunc}
	 * labeled alternative in {@link Anasint#expresion_asignacion1}.
	 * @param ctx the parse tree
	 */
	void enterAsignFunc(Anasint.AsignFuncContext ctx);
	/**
	 * Exit a parse tree produced by the {@code AsignFunc}
	 * labeled alternative in {@link Anasint#expresion_asignacion1}.
	 * @param ctx the parse tree
	 */
	void exitAsignFunc(Anasint.AsignFuncContext ctx);
	/**
	 * Enter a parse tree produced by the {@code AsigParentesis}
	 * labeled alternative in {@link Anasint#expresion_asignacion1}.
	 * @param ctx the parse tree
	 */
	void enterAsigParentesis(Anasint.AsigParentesisContext ctx);
	/**
	 * Exit a parse tree produced by the {@code AsigParentesis}
	 * labeled alternative in {@link Anasint#expresion_asignacion1}.
	 * @param ctx the parse tree
	 */
	void exitAsigParentesis(Anasint.AsigParentesisContext ctx);
	/**
	 * Enter a parse tree produced by the {@code AsigExplicitLista}
	 * labeled alternative in {@link Anasint#expresion_asignacion1}.
	 * @param ctx the parse tree
	 */
	void enterAsigExplicitLista(Anasint.AsigExplicitListaContext ctx);
	/**
	 * Exit a parse tree produced by the {@code AsigExplicitLista}
	 * labeled alternative in {@link Anasint#expresion_asignacion1}.
	 * @param ctx the parse tree
	 */
	void exitAsigExplicitLista(Anasint.AsigExplicitListaContext ctx);
	/**
	 * Enter a parse tree produced by the {@code AsigSimple}
	 * labeled alternative in {@link Anasint#expresion_asignacion1}.
	 * @param ctx the parse tree
	 */
	void enterAsigSimple(Anasint.AsigSimpleContext ctx);
	/**
	 * Exit a parse tree produced by the {@code AsigSimple}
	 * labeled alternative in {@link Anasint#expresion_asignacion1}.
	 * @param ctx the parse tree
	 */
	void exitAsigSimple(Anasint.AsigSimpleContext ctx);
	/**
	 * Enter a parse tree produced by {@link Anasint#operadores_aritmeticos}.
	 * @param ctx the parse tree
	 */
	void enterOperadores_aritmeticos(Anasint.Operadores_aritmeticosContext ctx);
	/**
	 * Exit a parse tree produced by {@link Anasint#operadores_aritmeticos}.
	 * @param ctx the parse tree
	 */
	void exitOperadores_aritmeticos(Anasint.Operadores_aritmeticosContext ctx);
	/**
	 * Enter a parse tree produced by {@link Anasint#ins_condicion}.
	 * @param ctx the parse tree
	 */
	void enterIns_condicion(Anasint.Ins_condicionContext ctx);
	/**
	 * Exit a parse tree produced by {@link Anasint#ins_condicion}.
	 * @param ctx the parse tree
	 */
	void exitIns_condicion(Anasint.Ins_condicionContext ctx);
	/**
	 * Enter a parse tree produced by {@link Anasint#expresion_condicional}.
	 * @param ctx the parse tree
	 */
	void enterExpresion_condicional(Anasint.Expresion_condicionalContext ctx);
	/**
	 * Exit a parse tree produced by {@link Anasint#expresion_condicional}.
	 * @param ctx the parse tree
	 */
	void exitExpresion_condicional(Anasint.Expresion_condicionalContext ctx);
	/**
	 * Enter a parse tree produced by the {@code CondCierto}
	 * labeled alternative in {@link Anasint#expresion_condicional1}.
	 * @param ctx the parse tree
	 */
	void enterCondCierto(Anasint.CondCiertoContext ctx);
	/**
	 * Exit a parse tree produced by the {@code CondCierto}
	 * labeled alternative in {@link Anasint#expresion_condicional1}.
	 * @param ctx the parse tree
	 */
	void exitCondCierto(Anasint.CondCiertoContext ctx);
	/**
	 * Enter a parse tree produced by the {@code CondFalse}
	 * labeled alternative in {@link Anasint#expresion_condicional1}.
	 * @param ctx the parse tree
	 */
	void enterCondFalse(Anasint.CondFalseContext ctx);
	/**
	 * Exit a parse tree produced by the {@code CondFalse}
	 * labeled alternative in {@link Anasint#expresion_condicional1}.
	 * @param ctx the parse tree
	 */
	void exitCondFalse(Anasint.CondFalseContext ctx);
	/**
	 * Enter a parse tree produced by the {@code CondNegacion}
	 * labeled alternative in {@link Anasint#expresion_condicional1}.
	 * @param ctx the parse tree
	 */
	void enterCondNegacion(Anasint.CondNegacionContext ctx);
	/**
	 * Exit a parse tree produced by the {@code CondNegacion}
	 * labeled alternative in {@link Anasint#expresion_condicional1}.
	 * @param ctx the parse tree
	 */
	void exitCondNegacion(Anasint.CondNegacionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code CondParentesis}
	 * labeled alternative in {@link Anasint#expresion_condicional1}.
	 * @param ctx the parse tree
	 */
	void enterCondParentesis(Anasint.CondParentesisContext ctx);
	/**
	 * Exit a parse tree produced by the {@code CondParentesis}
	 * labeled alternative in {@link Anasint#expresion_condicional1}.
	 * @param ctx the parse tree
	 */
	void exitCondParentesis(Anasint.CondParentesisContext ctx);
	/**
	 * Enter a parse tree produced by the {@code CondVar}
	 * labeled alternative in {@link Anasint#expresion_condicional1}.
	 * @param ctx the parse tree
	 */
	void enterCondVar(Anasint.CondVarContext ctx);
	/**
	 * Exit a parse tree produced by the {@code CondVar}
	 * labeled alternative in {@link Anasint#expresion_condicional1}.
	 * @param ctx the parse tree
	 */
	void exitCondVar(Anasint.CondVarContext ctx);
	/**
	 * Enter a parse tree produced by {@link Anasint#operadores_binarios}.
	 * @param ctx the parse tree
	 */
	void enterOperadores_binarios(Anasint.Operadores_binariosContext ctx);
	/**
	 * Exit a parse tree produced by {@link Anasint#operadores_binarios}.
	 * @param ctx the parse tree
	 */
	void exitOperadores_binarios(Anasint.Operadores_binariosContext ctx);
	/**
	 * Enter a parse tree produced by {@link Anasint#ins_iteracion}.
	 * @param ctx the parse tree
	 */
	void enterIns_iteracion(Anasint.Ins_iteracionContext ctx);
	/**
	 * Exit a parse tree produced by {@link Anasint#ins_iteracion}.
	 * @param ctx the parse tree
	 */
	void exitIns_iteracion(Anasint.Ins_iteracionContext ctx);
	/**
	 * Enter a parse tree produced by {@link Anasint#ins_ruptura}.
	 * @param ctx the parse tree
	 */
	void enterIns_ruptura(Anasint.Ins_rupturaContext ctx);
	/**
	 * Exit a parse tree produced by {@link Anasint#ins_ruptura}.
	 * @param ctx the parse tree
	 */
	void exitIns_ruptura(Anasint.Ins_rupturaContext ctx);
	/**
	 * Enter a parse tree produced by {@link Anasint#ins_devolucion}.
	 * @param ctx the parse tree
	 */
	void enterIns_devolucion(Anasint.Ins_devolucionContext ctx);
	/**
	 * Exit a parse tree produced by {@link Anasint#ins_devolucion}.
	 * @param ctx the parse tree
	 */
	void exitIns_devolucion(Anasint.Ins_devolucionContext ctx);
	/**
	 * Enter a parse tree produced by {@link Anasint#ins_mostrar}.
	 * @param ctx the parse tree
	 */
	void enterIns_mostrar(Anasint.Ins_mostrarContext ctx);
	/**
	 * Exit a parse tree produced by {@link Anasint#ins_mostrar}.
	 * @param ctx the parse tree
	 */
	void exitIns_mostrar(Anasint.Ins_mostrarContext ctx);
	/**
	 * Enter a parse tree produced by {@link Anasint#ins_procedimiento}.
	 * @param ctx the parse tree
	 */
	void enterIns_procedimiento(Anasint.Ins_procedimientoContext ctx);
	/**
	 * Exit a parse tree produced by {@link Anasint#ins_procedimiento}.
	 * @param ctx the parse tree
	 */
	void exitIns_procedimiento(Anasint.Ins_procedimientoContext ctx);
}