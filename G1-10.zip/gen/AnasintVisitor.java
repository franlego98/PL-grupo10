// Generated from C:/Users/Javier/IdeaProjects/PL-grupo10/src\Anasint.g4 by ANTLR 4.9
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link Anasint}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface AnasintVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link Anasint#programa}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPrograma(Anasint.ProgramaContext ctx);
	/**
	 * Visit a parse tree produced by {@link Anasint#variables}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVariables(Anasint.VariablesContext ctx);
	/**
	 * Visit a parse tree produced by {@link Anasint#decl_var}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDecl_var(Anasint.Decl_varContext ctx);
	/**
	 * Visit a parse tree produced by {@link Anasint#identificador_declaracion}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIdentificador_declaracion(Anasint.Identificador_declaracionContext ctx);
	/**
	 * Visit a parse tree produced by {@link Anasint#tipo_de_dato}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTipo_de_dato(Anasint.Tipo_de_datoContext ctx);
	/**
	 * Visit a parse tree produced by {@link Anasint#subprogramas}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSubprogramas(Anasint.SubprogramasContext ctx);
	/**
	 * Visit a parse tree produced by {@link Anasint#funcion}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFuncion(Anasint.FuncionContext ctx);
	/**
	 * Visit a parse tree produced by {@link Anasint#identificador_funcion}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIdentificador_funcion(Anasint.Identificador_funcionContext ctx);
	/**
	 * Visit a parse tree produced by {@link Anasint#procedimiento}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProcedimiento(Anasint.ProcedimientoContext ctx);
	/**
	 * Visit a parse tree produced by {@link Anasint#identificador_procedimiento}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIdentificador_procedimiento(Anasint.Identificador_procedimientoContext ctx);
	/**
	 * Visit a parse tree produced by {@link Anasint#argumento_subprograma_dev}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArgumento_subprograma_dev(Anasint.Argumento_subprograma_devContext ctx);
	/**
	 * Visit a parse tree produced by {@link Anasint#argumento_subprograma}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArgumento_subprograma(Anasint.Argumento_subprogramaContext ctx);
	/**
	 * Visit a parse tree produced by {@link Anasint#instrucciones}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInstrucciones(Anasint.InstruccionesContext ctx);
	/**
	 * Visit a parse tree produced by {@link Anasint#tipo_instruccion}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTipo_instruccion(Anasint.Tipo_instruccionContext ctx);
	/**
	 * Visit a parse tree produced by {@link Anasint#tipo_instruccion2}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTipo_instruccion2(Anasint.Tipo_instruccion2Context ctx);
	/**
	 * Visit a parse tree produced by {@link Anasint#ins_asignacion}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIns_asignacion(Anasint.Ins_asignacionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code identLista}
	 * labeled alternative in {@link Anasint#identificador_variables}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIdentLista(Anasint.IdentListaContext ctx);
	/**
	 * Visit a parse tree produced by the {@code identVarSimple}
	 * labeled alternative in {@link Anasint#identificador_variables}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIdentVarSimple(Anasint.IdentVarSimpleContext ctx);
	/**
	 * Visit a parse tree produced by {@link Anasint#expresion_asignacion}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExpresion_asignacion(Anasint.Expresion_asignacionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code AsigTrue}
	 * labeled alternative in {@link Anasint#expresion_asignacion1}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAsigTrue(Anasint.AsigTrueContext ctx);
	/**
	 * Visit a parse tree produced by the {@code AsigFalse}
	 * labeled alternative in {@link Anasint#expresion_asignacion1}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAsigFalse(Anasint.AsigFalseContext ctx);
	/**
	 * Visit a parse tree produced by the {@code AsigExplicit}
	 * labeled alternative in {@link Anasint#expresion_asignacion1}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAsigExplicit(Anasint.AsigExplicitContext ctx);
	/**
	 * Visit a parse tree produced by the {@code AsigLista}
	 * labeled alternative in {@link Anasint#expresion_asignacion1}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAsigLista(Anasint.AsigListaContext ctx);
	/**
	 * Visit a parse tree produced by the {@code AsignFunc}
	 * labeled alternative in {@link Anasint#expresion_asignacion1}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAsignFunc(Anasint.AsignFuncContext ctx);
	/**
	 * Visit a parse tree produced by the {@code AsigParentesis}
	 * labeled alternative in {@link Anasint#expresion_asignacion1}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAsigParentesis(Anasint.AsigParentesisContext ctx);
	/**
	 * Visit a parse tree produced by the {@code AsigExplicitLista}
	 * labeled alternative in {@link Anasint#expresion_asignacion1}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAsigExplicitLista(Anasint.AsigExplicitListaContext ctx);
	/**
	 * Visit a parse tree produced by the {@code AsigSimple}
	 * labeled alternative in {@link Anasint#expresion_asignacion1}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAsigSimple(Anasint.AsigSimpleContext ctx);
	/**
	 * Visit a parse tree produced by {@link Anasint#operadores_aritmeticos}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOperadores_aritmeticos(Anasint.Operadores_aritmeticosContext ctx);
	/**
	 * Visit a parse tree produced by {@link Anasint#ins_condicion}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIns_condicion(Anasint.Ins_condicionContext ctx);
	/**
	 * Visit a parse tree produced by {@link Anasint#expresion_condicional}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExpresion_condicional(Anasint.Expresion_condicionalContext ctx);
	/**
	 * Visit a parse tree produced by the {@code CondCierto}
	 * labeled alternative in {@link Anasint#expresion_condicional1}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCondCierto(Anasint.CondCiertoContext ctx);
	/**
	 * Visit a parse tree produced by the {@code CondFalse}
	 * labeled alternative in {@link Anasint#expresion_condicional1}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCondFalse(Anasint.CondFalseContext ctx);
	/**
	 * Visit a parse tree produced by the {@code CondNegacion}
	 * labeled alternative in {@link Anasint#expresion_condicional1}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCondNegacion(Anasint.CondNegacionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code CondParentesis}
	 * labeled alternative in {@link Anasint#expresion_condicional1}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCondParentesis(Anasint.CondParentesisContext ctx);
	/**
	 * Visit a parse tree produced by the {@code CondVar}
	 * labeled alternative in {@link Anasint#expresion_condicional1}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCondVar(Anasint.CondVarContext ctx);
	/**
	 * Visit a parse tree produced by {@link Anasint#operadores_binarios}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOperadores_binarios(Anasint.Operadores_binariosContext ctx);
	/**
	 * Visit a parse tree produced by {@link Anasint#ins_iteracion}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIns_iteracion(Anasint.Ins_iteracionContext ctx);
	/**
	 * Visit a parse tree produced by {@link Anasint#ins_ruptura}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIns_ruptura(Anasint.Ins_rupturaContext ctx);
	/**
	 * Visit a parse tree produced by {@link Anasint#ins_devolucion}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIns_devolucion(Anasint.Ins_devolucionContext ctx);
	/**
	 * Visit a parse tree produced by {@link Anasint#ins_mostrar}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIns_mostrar(Anasint.Ins_mostrarContext ctx);
	/**
	 * Visit a parse tree produced by {@link Anasint#ins_procedimiento}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIns_procedimiento(Anasint.Ins_procedimientoContext ctx);
}